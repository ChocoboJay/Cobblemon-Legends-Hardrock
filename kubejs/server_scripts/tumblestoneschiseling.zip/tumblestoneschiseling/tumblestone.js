ServerEvents.recipes(event => {
    event.custom({
"type": "create:sandpaper_polishing",
  "ingredients": [
    {
      "item": "tfc:rock/smooth/chert"
    }
  ],
  "results": [
    {
      "item": "cobblemon:tumblestone"
    }
  ]
})})