ServerEvents.recipes(event => {
    event.custom({
"type": "create:sandpaper_polishing",
  "ingredients": [
    {
      "item": "tfc:rock/smooth/conglomerate"
    }
  ],
  "results": [
    {
      "item": "cobblemon:sky_tumblestone"
    }
  ]
})})