ServerEvents.recipes(event => {
    event.custom({
"type": "create:sandpaper_polishing",
  "ingredients": [
    {
      "item": "tfc:rock/smooth/basalt"
    }
  ],
  "results": [
    {
      "item": "cobblemon:black_tumblestone"
    }
  ]
})})